first install npm by 'npm install'
to run use 'npm start' command
to build use 'npm run build' command

Components
- NavBar.js - Nav bar that contains the header/className
- TeamCard.js - manages/displays each of the individual team info cards

Libraries
Material-UI, React components that implement Google's Material Design.
axios, Promise based HTTP client for the browser and node.js

Bugs 
Projects cannot be selected 
the map function does not seem to work. 
