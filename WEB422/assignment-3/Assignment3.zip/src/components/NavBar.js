import React from 'react'

function NavBar() {
    return (
        <nav className="navbar navbar-default">
            <div className="container-fluid">
                <div className="navbar-header">
                    <h3 className="navbar-brand" >Assignment 3 - Team Details</h3>
                </div> 
            </div>
        </nav>
    );
}
export default NavBar
